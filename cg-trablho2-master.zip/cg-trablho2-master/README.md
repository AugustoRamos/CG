# cg-trablho2
Trabalho 2 de CG desenvolvido utilizando OpenGL e freeglut3

Para compilar

sudo apt-get install freeglut3
sudo apt-get install freeglut3-dev
